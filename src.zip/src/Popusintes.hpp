#include "rack.hpp"

using namespace rack;

extern Plugin *pluginInstance;

extern Model *modelCompa;
extern Model *modelPanel;
extern Model *modelRelo;
extern Model *modelRerelo;
extern Model *modelSecu;
